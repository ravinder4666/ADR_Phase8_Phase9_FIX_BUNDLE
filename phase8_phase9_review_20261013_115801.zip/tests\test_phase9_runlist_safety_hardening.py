import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration


class FakeImage:
    def __init__(self, path, data):
        self.path = path
        self.data = data

    def inspect(self):
        return {"ready": True, "size": len(self.data)}

    def read_at(self, offset, length):
        return self.data[offset:offset + length]


class Phase9RunlistSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / "source.img"
        self.data = b"AAAABBBBCCCCDDDDEEEEFFFF"
        self.source.write_bytes(self.data)

        self.recovery = NTFSRecoveryIntegration.__new__(NTFSRecoveryIntegration)
        self.recovery.image_path = self.source.resolve()
        self.recovery.image = FakeImage(self.source, self.data)
        self.recovery.geometry = SimpleNamespace(cluster_size=4)
        self.recovery.partition_offset = 0
        self.recovery.max_output_size = 1024

    def tearDown(self):
        self.temp.cleanup()

    def test_valid_fragmented_runs_reconstruct_in_order(self):
        target = self.root / "recovered.bin"
        result = self.recovery.reconstruct_runs([
            {"lcn": 1, "clusters": 1, "sparse": False},
            {"lcn": 3, "clusters": 1, "sparse": False},
        ], 8, target)
        self.assertTrue(result["passed"])
        self.assertEqual(target.read_bytes(), b"BBBB" + b"DDDD")

    def test_rejects_non_boolean_sparse_flag(self):
        with self.assertRaisesRegex(ValueError, "sparse-run flag"):
            self.recovery.reconstruct_runs([
                {"lcn": 1, "clusters": 1, "sparse": "false"}
            ], 4, self.root / "bad.bin")

    def test_rejects_physical_lcn_on_sparse_run(self):
        with self.assertRaisesRegex(ValueError, "sparse run"):
            self.recovery.reconstruct_runs([
                {"lcn": 1, "clusters": 1, "sparse": True}
            ], 4, self.root / "bad.bin")

    def test_rejects_overlapping_physical_clusters(self):
        with self.assertRaisesRegex(ValueError, "overlapping physical"):
            self.recovery.reconstruct_runs([
                {"lcn": 1, "clusters": 2, "sparse": False},
                {"lcn": 2, "clusters": 1, "sparse": False},
            ], 12, self.root / "bad.bin")

    def test_rejects_boolean_cluster_count(self):
        with self.assertRaisesRegex(ValueError, "cluster count"):
            self.recovery.reconstruct_runs([
                {"lcn": 1, "clusters": True, "sparse": False}
            ], 4, self.root / "bad.bin")


if __name__ == "__main__":
    unittest.main()
