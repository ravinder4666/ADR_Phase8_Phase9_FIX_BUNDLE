"""Resolve a relative output path without escaping the selected output root."""
from pathlib import Path

def resolve_recovery_path(output_root, relative_path, allow_overwrite=False):
    if relative_path is None:
        raise ValueError("relative output path is required")
    relative_text = str(relative_path)
    if not relative_text.strip():
        raise ValueError("relative output path is required")
    if "\x00" in relative_text:
        raise ValueError("NUL bytes are not allowed in output paths")

    root = Path(output_root).expanduser().resolve()
    raw = Path(relative_text)
    if raw.is_absolute() or raw.drive:
        raise ValueError("absolute paths are not allowed")
    if any(part == ".." for part in raw.parts):
        raise ValueError("parent traversal is not allowed")
    target = (root / raw).resolve()
    try:
        target.relative_to(root)
    except ValueError as exc:
        raise ValueError("output path escapes output root") from exc
    if target == root:
        raise ValueError("output path must name a file below the root")
    if target.exists() and not allow_overwrite:
        raise FileExistsError(str(target))
    return target