﻿"""Verify an already-created output file; never creates or alters that file."""
import hashlib
from pathlib import Path


def verify_recovered_output(path, expected_size=None, expected_sha256=None,
                            chunk_size=1024 * 1024):
    if not isinstance(chunk_size, int) or isinstance(chunk_size, bool) or chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")

    p = Path(path)
    errors = []
    actual_size = None
    actual_hash = None

    try:
        if not p.is_file():
            errors.append("output is not a regular file")
        else:
            actual_size = p.stat().st_size
            digest = hashlib.sha256()
            with p.open("rb") as stream:
                while True:
                    block = stream.read(chunk_size)
                    if not block:
                        break
                    digest.update(block)
            actual_hash = digest.hexdigest()
    except OSError as exc:
        errors.append(f"output verification failed: {type(exc).__name__}")

    if actual_size is not None and expected_size is not None:
        if actual_size != expected_size:
            errors.append("size mismatch")

    if expected_sha256 is not None:
        if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
            errors.append("expected_sha256 must be a 64-character hex digest")
        elif any(c not in "0123456789abcdefABCDEF" for c in expected_sha256):
            errors.append("expected_sha256 is not hexadecimal")
        elif actual_hash is not None and actual_hash.lower() != expected_sha256.lower():
            errors.append("SHA-256 mismatch")

    return {
        "verified": not errors and actual_size is not None and actual_hash is not None,
        "path": str(p),
        "actual_size": actual_size,
        "sha256": actual_hash,
        "errors": errors,
    }
