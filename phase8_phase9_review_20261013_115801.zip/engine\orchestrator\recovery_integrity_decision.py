﻿"""Integrity gate: only complete, bounded, hash-matching bytes can be approved."""
from dataclasses import dataclass
import hashlib

@dataclass(frozen=True)
class IntegrityDecision:
    approved: bool
    size: int
    sha256: str | None
    reasons: tuple[str, ...]

def evaluate_recovery(data: bytes, *, expected_size: int, expected_sha256: str | None,
                      metadata_consistent: bool, extents_complete: bool,
                      source_read_only: bool = True) -> IntegrityDecision:
    reasons = []
    if not isinstance(data, bytes):
        return IntegrityDecision(False, 0, None, ("recovered data must be bytes",))
    digest = hashlib.sha256(data).hexdigest()
    if not isinstance(expected_size, int) or expected_size < 0 or len(data) != expected_size:
        reasons.append("recovered byte count does not match expected size")
    if expected_sha256 is not None:
        if not isinstance(expected_sha256, str) or len(expected_sha256) != 64:
            reasons.append("expected SHA-256 must be 64 hexadecimal characters")
        else:
            try:
                int(expected_sha256, 16)
            except ValueError:
                reasons.append("expected SHA-256 is not hexadecimal")
            else:
                if digest.lower() != expected_sha256.lower():
                    reasons.append("SHA-256 mismatch")
    if not metadata_consistent:
        reasons.append("metadata consistency gate failed")
    if not extents_complete:
        reasons.append("extent completeness gate failed")
    if not source_read_only:
        reasons.append("source was not confirmed read-only")
    return IntegrityDecision(not reasons, len(data), digest, tuple(reasons) if reasons else ("integrity checks passed",))
