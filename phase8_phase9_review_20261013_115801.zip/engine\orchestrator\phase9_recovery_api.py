"""Explicit, bounded Phase 9 recovery API adapter."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
IMAGE_ROOT = (ROOT / "test_images").resolve()
OUTPUT_ROOT = ROOT / "recovered_files"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def recover_candidate(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise TypeError("Request must be a JSON object")

    image_name = payload.get("image")
    if not isinstance(image_name, str) or not image_name or Path(image_name).name != image_name:
        raise ValueError("'image' must be a filename inside test_images")

    source = (IMAGE_ROOT / image_name).resolve(strict=True)
    if source.parent != IMAGE_ROOT or not source.is_file():
        raise ValueError("Image must be a regular file directly inside test_images")

    record_offset = payload.get("record_offset")
    if isinstance(record_offset, bool) or not isinstance(record_offset, int) or record_offset < 0:
        raise ValueError("'record_offset' must be a non-negative integer")

    geometry_data = payload.get("geometry")
    if not isinstance(geometry_data, dict):
        raise ValueError("'geometry' must contain validated NTFS geometry")
    required = ("bytes_per_sector", "cluster_size", "mft_record_size", "mft_lcn")
    values = {}
    for key in required:
        value = geometry_data.get(key)
        minimum = 0 if key == "mft_lcn" else 1
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            raise ValueError(f"geometry.{key} is invalid")
        values[key] = value

    partition_offset = payload.get("partition_offset", 0)
    if isinstance(partition_offset, bool) or not isinstance(partition_offset, int) or partition_offset < 0:
        raise ValueError("'partition_offset' must be a non-negative integer")

    destination_name = payload.get("destination")
    if (not isinstance(destination_name, str) or not destination_name
            or Path(destination_name).name != destination_name
            or destination_name in (".", "..")):
        raise ValueError("'destination' must be a plain output filename")

    expected = payload.get("expected_sha256")
    if expected is not None:
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
            raise ValueError("'expected_sha256' must be a 64-character SHA-256 digest")
        expected = expected.lower()


    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    destination = (OUTPUT_ROOT / destination_name).resolve()
    if destination.parent != OUTPUT_ROOT.resolve():
        raise ValueError("Destination must remain inside recovered_files")
    if destination == source or destination.exists():
        raise FileExistsError(str(destination))

    from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration

    geometry = SimpleNamespace(**values)
    source_hash_before = _sha256(source)
    engine = NTFSRecoveryIntegration(
        image_path=source,
        geometry=geometry,
        partition_offset=partition_offset,
    )

    result = engine.recover_deleted_record(
        record_offset=record_offset,
        destination=destination,
        expected_sha256=expected,
    )

    source_hash_after = _sha256(source)
    source_unchanged = source_hash_before == source_hash_after
    output_exists = destination.is_file()
    output_hash = _sha256(destination) if output_exists else None
    output_size = destination.stat().st_size if output_exists else None

    passed = (
        bool(result.get("passed", result.get("valid", False)))
        if isinstance(result, dict) else bool(result)
    )
    reported_size = result.get("size") if isinstance(result, dict) else None
    known_hash_match = bool(expected is not None and output_hash == expected and output_exists)

    if not source_unchanged:
        recovery_status = "SOURCE_MODIFIED"
        status_reason = "Source image hash changed during recovery"
    elif not output_exists:
        recovery_status = "OUTPUT_MISSING" if passed else "RECOVERY_FAILED"
        status_reason = "Engine reported success but no output exists" if passed else "No recovery output was produced"
    elif isinstance(reported_size, int) and not isinstance(reported_size, bool) and output_size != reported_size:
        recovery_status = "INCOMPLETE_OUTPUT" if output_size < reported_size else "DAMAGED_OUTPUT"
        status_reason = "Output size differs from the engine-reported recovered size"
    elif expected is None:
        recovery_status = "UNVERIFIABLE_OUTPUT"
        status_reason = "No independently known original SHA-256 was supplied"
    elif not known_hash_match:
        recovery_status = "DAMAGED_OUTPUT"
        status_reason = "Output does not match the independently supplied expected SHA-256"
    elif not passed:
        recovery_status = "RECOVERY_FAILED"
        status_reason = "Engine did not report successful recovery and verification"
    else:
        recovery_status = "VERIFIED_OUTPUT"
        status_reason = "Engine passed, source is unchanged, and output matches the expected SHA-256"

    return {
        "status": recovery_status,
        "status_reason": status_reason,
        "engine_result": result,
        "source_sha256_before": source_hash_before,
        "source_sha256_after": source_hash_after,
        "source_unchanged": source_unchanged,
        "output_path": str(destination) if output_exists else None,
        "output_size": output_size,
        "engine_reported_size": reported_size,
        "output_sha256": output_hash,
        "expected_sha256_supplied": expected is not None,
        "expected_sha256_match": known_hash_match,
        "known_original_hash_verified": known_hash_match,
        "limitations": [
            "Only images located directly inside test_images are accepted",
            "Geometry must be supplied from a trusted NTFS inspection",
            "A matching hash is meaningful only when the expected hash comes from an independent trusted source",
            "A synthetic-image test does not establish real-world recovery capability",
        ],
    }
