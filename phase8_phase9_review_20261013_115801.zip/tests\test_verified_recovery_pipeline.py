﻿import unittest

from engine.orchestrator.verified_recovery_pipeline import VerifiedRecoveryPipeline


class TestVerifiedRecoveryPipeline(unittest.TestCase):
    def test_runs_stages_in_order(self):
        calls = []
        pipeline = VerifiedRecoveryPipeline([
            ("scan", lambda ctx: calls.append("scan") or {"passed": True, "count": 2}),
            ("validate", lambda ctx: calls.append("validate") or {"passed": True}),
            ("verify", lambda ctx: calls.append("verify") or {"passed": True}),
        ])
        result = pipeline.run()
        self.assertTrue(result["passed"])
        self.assertEqual(calls, ["scan", "validate", "verify"])

    def test_false_result_stops_later_stages(self):
        calls = []
        pipeline = VerifiedRecoveryPipeline([
            ("scan", lambda ctx: {"passed": True}),
            ("validate", lambda ctx: {"passed": False, "reason": "bad_record"}),
            ("publish", lambda ctx: calls.append("publish") or {"passed": True}),
        ])
        result = pipeline.run()
        self.assertFalse(result["passed"])
        self.assertEqual(calls, [])
        self.assertTrue(result["stages"][2]["details"]["skipped"])

    def test_exception_stops_later_stages(self):
        def broken(_):
            raise OSError("fixture failure")

        pipeline = VerifiedRecoveryPipeline([
            ("read", broken),
            ("publish", lambda ctx: {"passed": True}),
        ])
        result = pipeline.run()
        self.assertFalse(result["passed"])
        self.assertEqual(result["stages"][0]["details"]["error_type"], "OSError")
        self.assertTrue(result["stages"][1]["details"]["skipped"])

    def test_rejects_missing_pass_flag(self):
        pipeline = VerifiedRecoveryPipeline([
            ("validate", lambda ctx: {"valid": True})
        ])
        self.assertFalse(pipeline.run()["passed"])

    def test_rejects_duplicate_stage_names(self):
        with self.assertRaises(ValueError):
            VerifiedRecoveryPipeline([
                ("scan", lambda ctx: {"passed": True}),
                ("scan", lambda ctx: {"passed": True}),
            ])

    def test_rejects_empty_pipeline(self):
        with self.assertRaises(ValueError):
            VerifiedRecoveryPipeline([])

    def test_passed_stage_context_is_available_to_next_stage(self):
        pipeline = VerifiedRecoveryPipeline([
            ("scan", lambda ctx: {"passed": True, "count": 7}),
            ("validate", lambda ctx: {
                "passed": ctx["scan"]["count"] == 7
            }),
        ])
        self.assertTrue(pipeline.run()["passed"])


if __name__ == "__main__":
    unittest.main()
