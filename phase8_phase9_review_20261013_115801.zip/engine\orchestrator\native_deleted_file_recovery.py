﻿"""Conservative deleted-NTFS-file discovery and independently verified recovery."""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from engine.orchestrator.ntfs_recovery_pipeline import NTFSRecoveryPipeline
from engine.orchestrator.native_ntfs_recovery_service import recover_from_runlist
from engine.filesystem.ntfs_native_bridge import parse_runlist


def _fixup_record(record: bytes, sector_size: int) -> bytes:
    if len(record) < 48 or record[:4] != b"FILE":
        raise ValueError("Invalid NTFS FILE record signature")
    if sector_size <= 0 or len(record) % sector_size:
        raise ValueError("Invalid FILE record or sector geometry")

    usa_offset = int.from_bytes(record[4:6], "little")
    usa_count = int.from_bytes(record[6:8], "little")
    expected = len(record) // sector_size + 1
    if usa_count != expected or usa_offset < 8:
        raise ValueError("Invalid update-sequence array")
    if usa_offset + usa_count * 2 > len(record):
        raise ValueError("Update-sequence array exceeds record boundary")

    result = bytearray(record)
    sequence = record[usa_offset:usa_offset + 2]
    for i in range(1, usa_count):
        trailer = i * sector_size - 2
        replacement = usa_offset + i * 2
        if trailer + 2 > len(record) or replacement + 2 > len(record):
            raise ValueError("Update-sequence fixup boundary violation")
        if record[trailer:trailer + 2] != sequence:
            raise ValueError("NTFS update-sequence fixup mismatch")
        result[trailer:trailer + 2] = record[replacement:replacement + 2]
    return bytes(result)


def parse_deleted_record(record: bytes, sector_size: int = 512) -> dict[str, Any] | None:
    """Parse a deleted regular-file FILE record; None means not eligible."""
    record = _fixup_record(record, sector_size)
    flags = int.from_bytes(record[22:24], "little")
    if flags & 0x01 or flags & 0x02:  # in-use or directory
        return None

    first = int.from_bytes(record[20:22], "little")
    used = int.from_bytes(record[24:28], "little")
    allocated = int.from_bytes(record[28:32], "little")
    if not (48 <= first <= used <= allocated <= len(record)):
        raise ValueError("Invalid FILE record attribute bounds")

    name = None
    data_attr = None
    pos = first
    while pos + 8 <= used:
        attr_type = int.from_bytes(record[pos:pos + 4], "little")
        if attr_type == 0xFFFFFFFF:
            break
        length = int.from_bytes(record[pos + 4:pos + 8], "little")
        if length < 8 or pos + length > used:
            raise ValueError("Invalid NTFS attribute boundary")
        nonresident = record[pos + 8]
        name_length = record[pos + 9]
        name_offset = int.from_bytes(record[pos + 10:pos + 12], "little")
        attr_name = ""
        if name_length:
            begin = pos + name_offset
            end = begin + name_length * 2
            if name_offset < 16 or end > pos + length:
                raise ValueError("Invalid NTFS attribute-name boundary")
            attr_name = record[begin:end].decode("utf-16le", errors="strict")

        if attr_type == 0x30 and nonresident == 0:
            value_length = int.from_bytes(record[pos + 16:pos + 20], "little")
            value_offset = int.from_bytes(record[pos + 20:pos + 22], "little")
            begin = pos + value_offset
            end = begin + value_length
            if value_offset < 24 or end > pos + length:
                raise ValueError("Invalid FILE_NAME attribute boundary")
            value = record[begin:end]
            if len(value) >= 66:
                chars = value[64]
                if 66 + chars * 2 <= len(value):
                    candidate = value[66:66 + chars * 2].decode("utf-16le")
                    if candidate and not attr_name:
                        name = candidate

        elif attr_type == 0x80 and nonresident == 1 and not attr_name:
            if data_attr is not None:
                raise ValueError("Multiple unnamed non-resident DATA attributes")
            if length < 64:
                raise ValueError("Truncated non-resident DATA attribute")
            run_offset = int.from_bytes(record[pos + 32:pos + 34], "little")
            real_size = int.from_bytes(record[pos + 48:pos + 56], "little")
            if run_offset < 64 or run_offset >= length:
                raise ValueError("Invalid DATA runlist offset")
            raw = record[pos + run_offset:pos + length]
            # Only a zero header terminates a runlist; fields may contain zero bytes.
            cursor = 0
            terminated = False
            while cursor < len(raw):
                header = raw[cursor]
                if header == 0:
                    raw = raw[:cursor + 1]
                    terminated = True
                    break
                length_width = header & 0x0F
                offset_width = header >> 4
                if length_width == 0 or length_width > 8 or offset_width > 8:
                    raise ValueError('Invalid runlist field widths')
                entry_end = cursor + 1 + length_width + offset_width
                if entry_end > len(raw):
                    raise ValueError('Truncated runlist entry')
                cursor = entry_end
            if not terminated:
                raise ValueError('DATA runlist terminator missing')
            data_attr = {"real_size": real_size, "runlist": raw}

        pos += length

    if not name or data_attr is None or data_attr["real_size"] <= 0:
        return None

    parsed = parse_runlist(data_attr["runlist"], max_runs=4096)
    if not parsed or any(not isinstance(r, dict) for r in parsed):
        raise ValueError("DATA runlist failed validation")
    if any(r.get("sparse") for r in parsed):
        raise ValueError("Sparse deleted-file data is not supported by this path")
    if any(not isinstance(r.get("lcn"), int) or r["lcn"] < 0
           or not isinstance(r.get("clusters"), int) or r["clusters"] <= 0
           for r in parsed):
        raise ValueError("Invalid physical DATA run")

    return {
        "name": name,
        "flags": flags,
        "real_size": data_attr["real_size"],
        "runlist": data_attr["runlist"],
        "run_count": len(parsed),
        "scope": "deleted FILE record with a parseable non-resident unnamed DATA attribute",
    }


def discover_deleted_files(
    image_path: str,
    *,
    partition_offset: int = 0,
    max_records: int = 100_000,
    max_output_size: int = 64 * 1024 * 1024,
) -> dict[str, Any]:
    """Find candidate deleted regular files in the bounded discovered MFT region."""
    pipeline = NTFSRecoveryPipeline(
        image_path, partition_offset=partition_offset,
        max_output_size=max_output_size
    )
    inspection = pipeline.inspect_volume()
    if not inspection.get("passed"):
        raise ValueError("NTFS volume inspection failed: " + str(inspection.get("error")))

    discovery = pipeline.discover_mft_records(max_records=max_records)
    if not discovery.get("passed"):
        raise ValueError("MFT discovery failed: " + str(discovery.get("error")))

    files = []
    rejected = 0
    for candidate in discovery["candidates"]:
        record = pipeline.image.read_at(candidate["offset"], candidate["record_size"])
        if len(record) != candidate["record_size"]:
            raise IOError("Short read while examining MFT candidate")
        try:
            item = parse_deleted_record(record, pipeline.geometry.bytes_per_sector)
        except (ValueError, UnicodeError):
            rejected += 1
            continue
        if item is None:
            continue
        item["record_offset"] = candidate["offset"]
        item["record_sequence_number"] = candidate["sequence_number"]
        item["record_size"] = candidate["record_size"]
        item["runlist_hex"] = item.pop("runlist").hex()
        files.append(item)

    return {
        "passed": True,
        "candidate_count": discovery["candidate_count"],
        "deleted_file_count": len(files),
        "rejected_malformed_records": rejected,
        "files": files,
        "source_modified": False,
        "scope": (
            "Bounded scan of the discovered MFT region only. "
            "MFT extent mapping, filename parent-directory validation, "
            "and complete deleted-file ownership are not established."
        ),
    }


def recover_deleted_file(
    image_path: str,
    destination: str,
    *,
    record_offset: int,
    expected_sha256: str,
    partition_offset: int = 0,
    max_records: int = 100_000,
    max_output_size: int = 64 * 1024 * 1024,
) -> dict[str, Any]:
    """Recover one discovered candidate only when a trusted independent hash matches."""
    if not isinstance(record_offset, int) or record_offset < 0:
        raise ValueError("Invalid MFT record offset")
    listing = discover_deleted_files(
        image_path, partition_offset=partition_offset,
        max_records=max_records, max_output_size=max_output_size
    )
    matches = [f for f in listing["files"] if f["record_offset"] == record_offset]
    if len(matches) != 1:
        raise ValueError("Selected offset is not one uniquely eligible deleted-file candidate")
    item = matches[0]

    result = recover_from_runlist(
        image_path, destination, bytes.fromhex(item["runlist_hex"]),
        real_size=item["real_size"], expected_sha256=expected_sha256,
        partition_offset=partition_offset, max_output_size=max_output_size
    )
    return {
        **result,
        "file_name_candidate": item["name"],
        "mft_record_offset": record_offset,
        "run_count": item["run_count"],
        "mft_to_file_ownership_proven": False,
        "scope": (
            "Independent hash verified for bytes extracted from the selected candidate's "
            "runlist. Filename/parent ownership and general deleted-file recoverability "
            "are not proven by this result."
        ),
    }
