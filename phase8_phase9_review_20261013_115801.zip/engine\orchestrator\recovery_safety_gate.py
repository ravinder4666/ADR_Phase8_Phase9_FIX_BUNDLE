"""Prevents unsafe recovery decisions; it does not perform file writes."""

from pathlib import Path

def evaluate_recovery_safety(source, destination, source_read_only=True,
                             destination_exists=False, overwrite_approved=False):
    errors = []
    if not str(source).strip() or not str(destination).strip():
        errors.append("source and destination are required")
    else:
        try:
            if Path(source).resolve() == Path(destination).resolve():
                errors.append("source and destination resolve to the same path")
        except (OSError, ValueError, RuntimeError):
            errors.append("could not safely resolve source/destination")

    if not source_read_only:
        errors.append("source must remain read-only")
    if destination_exists and not overwrite_approved:
        errors.append("existing destination overwrite is not approved")

    return {
        "safe_to_proceed": not errors,
        "errors": errors,
        "source_write_permitted": False,
        "overwrite_approved": bool(destination_exists and overwrite_approved)
    }