﻿"""Isolated integration of the NTFS runlist parser and safe recovery pipeline."""
from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path
from types import SimpleNamespace

from engine.filesystem.ntfs_native_bridge import parse_runlist
from engine.orchestrator.ntfs_recovery_pipeline import NTFSRecoveryPipeline


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _validated_runs(raw_runlist: bytes, max_runs: int = 4096):
    if not isinstance(raw_runlist, bytes) or not raw_runlist:
        raise ValueError("A non-empty raw NTFS runlist is required")
    parsed = parse_runlist(raw_runlist, max_runs=max_runs)
    if not parsed or len(parsed) > max_runs:
        raise ValueError("Runlist is empty or exceeds configured limit")

    runs = []
    for item in parsed:
        if not isinstance(item, dict):
            raise ValueError("Unexpected runlist parser result")
        lcn, clusters = item.get("lcn"), item.get("clusters")
        if item.get("sparse", False):
            raise ValueError("Sparse extents require a separate sparse-data policy")
        if not isinstance(lcn, int) or isinstance(lcn, bool) or lcn < 0:
            raise ValueError("Invalid physical LCN")
        if not isinstance(clusters, int) or isinstance(clusters, bool) or clusters <= 0:
            raise ValueError("Invalid run cluster count")
        runs.append(SimpleNamespace(lcn=lcn, clusters=clusters, sparse=False))
    return tuple(runs)


def recover_from_runlist(
    image_path: str,
    destination: str,
    raw_runlist: bytes,
    *,
    real_size: int,
    expected_sha256: str,
    partition_offset: int = 0,
    max_output_size: int = 64 * 1024 * 1024,
) -> dict:
    """Recover from caller-supplied raw runlist and independently verify content.

    This function does not discover a deleted file's MFT record or prove that
    the supplied runlist belongs to that file. The expected hash must be
    independently trusted.
    """
    source = Path(image_path).resolve(strict=True)
    target = Path(destination).resolve()

    if source == target:
        raise ValueError("Destination cannot be the source image")
    if target.exists():
        raise FileExistsError(f"Refusing to overwrite: {target}")
    if not isinstance(real_size, int) or isinstance(real_size, bool):
        raise ValueError("real_size must be an integer")
    if real_size <= 0 or real_size > max_output_size:
        raise ValueError("real_size is outside the configured output limit")
    if not isinstance(partition_offset, int) or partition_offset < 0:
        raise ValueError("Invalid partition offset")
    if (not isinstance(expected_sha256, str)
        or len(expected_sha256) != 64
        or any(c not in "0123456789abcdefABCDEF" for c in expected_sha256)):
        raise ValueError("A valid independent SHA-256 is required")

    runs = _validated_runs(raw_runlist)
    target.parent.mkdir(parents=True, exist_ok=True)
    source_hash_before = _sha256_file(source)

    fd, temp_name = tempfile.mkstemp(
        prefix=".adr-native-integration-", suffix=".tmp", dir=str(target.parent)
    )
    os.close(fd)
    temp = Path(temp_name)
    temp.unlink()

    try:
        pipeline = NTFSRecoveryPipeline(
            source,
            partition_offset=partition_offset,
            max_output_size=max_output_size,
        )
        inspection = pipeline.inspect_volume()
        if not inspection.get("passed"):
            raise ValueError(
                "NTFS volume inspection failed: "
                + str(inspection.get("error", inspection))
            )

        # Recheck geometry and physical extent boundaries before extraction.
        geometry = pipeline.geometry
        if geometry is None or geometry.cluster_size <= 0:
            raise ValueError("Validated NTFS cluster geometry is unavailable")
        image_size = source.stat().st_size
        for run in runs:
            start = partition_offset + run.lcn * geometry.cluster_size
            end = start + run.clusters * geometry.cluster_size
            if end < start or end > image_size:
                raise ValueError("Runlist extent exceeds source image boundary")

        result = pipeline.extract_verified_bytes(runs, real_size, temp)
        if not result.get("passed") or not temp.is_file():
            raise ValueError("Recovery pipeline did not verify its output")

        actual_size = temp.stat().st_size
        actual_hash = _sha256_file(temp)
        if actual_size != real_size:
            raise ValueError("Recovered file size does not match expected size")
        if actual_hash.lower() != expected_sha256.lower():
            raise ValueError("Independent expected SHA-256 mismatch")

        if _sha256_file(source) != source_hash_before:
            raise RuntimeError("Source image changed during recovery")

        # Same-directory hard link publishes atomically and won't overwrite.
        os.link(temp, target)
        return {
            "passed": True,
            "status": "INDEPENDENT_HASH_VERIFIED",
            "path": str(target),
            "size": actual_size,
            "sha256": actual_hash,
            "source_unchanged": True,
            "native_runlist_parser_available": True,
            "recoverability_proven": True,
            "scope": (
                "Supplied runlist and independent expected hash only; "
                "MFT-to-runlist ownership is not independently established."
            ),
        }
    finally:
        try:
            temp.unlink(missing_ok=True)
        except OSError:
            pass
