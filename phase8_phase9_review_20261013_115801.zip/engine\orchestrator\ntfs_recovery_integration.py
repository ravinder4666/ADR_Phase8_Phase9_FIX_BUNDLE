"""Conservative NTFS metadata integration for read-only disk images.

MFT candidates are evidence of plausible record locations, not proof that
deleted content can be reconstructed. Source image access remains read-only.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from engine.acquisition.disk_image_workflow_adapter import DiskImageWorkflowAdapter
from engine.filesystem.ntfs_mft_parser import NTFSMFTParser
from engine.filesystem.ntfs_attribute_parser import NTFSAttributeParser
from engine.filesystem.ntfs_data_run_parser import NTFSDataRunParser
from engine.filesystem.ntfs_file_name_attribute import NTFSFileNameAttributeParser
from engine.orchestrator.atomic_recovery_output_writer import write_recovery_output
from engine.orchestrator.recovered_output_integrity_verifier import verify_output


class NTFSRecoveryIntegration:
    """Parse discovered MFT records and safely reconstruct supplied extents."""

    FILE_NAME_ATTRIBUTE = 0x30
    DATA_ATTRIBUTE = 0x80
    END_ATTRIBUTE = 0xFFFFFFFF

    def __init__(self, image_path, geometry, partition_offset=0,
                 max_output_size=64 * 1024 * 1024):
        self.image_path = Path(image_path).resolve()
        if isinstance(partition_offset, bool) or not isinstance(partition_offset, int) or partition_offset < 0:
            raise ValueError("partition_offset must be a non-negative integer")
        if isinstance(max_output_size, bool) or not isinstance(max_output_size, int) or max_output_size <= 0:
            raise ValueError("max_output_size must be positive")
        for field in ("bytes_per_sector", "cluster_size", "mft_record_size"):
            value = getattr(geometry, field, None)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ValueError(f"invalid volume geometry field: {field}")

        self.geometry = geometry
        self.partition_offset = partition_offset
        self.max_output_size = max_output_size
        self.image = DiskImageWorkflowAdapter(self.image_path)
        self.mft_parser = NTFSMFTParser()
        self.attribute_parser = NTFSAttributeParser()
        self.run_parser = NTFSDataRunParser()
        self.filename_parser = NTFSFileNameAttributeParser()

    def parse_record_at(self, offset: int) -> dict[str, Any]:
        """Parse one MFT record at an absolute image offset."""
        if isinstance(offset, bool) or not isinstance(offset, int) or offset < self.partition_offset:
            raise ValueError("record offset is outside the partition range")

        status = self.image.inspect()
        if not status.get("ready"):
            return {"passed": False, "error": status.get("error", "Image unavailable")}

        record_size = self.geometry.mft_record_size
        image_size = status.get("size")
        if not isinstance(image_size, int) or offset + record_size > image_size:
            return {"passed": False, "error": "MFT record exceeds image bounds"}

        raw = self.image.read_at(offset, record_size)
        try:
            record = self.mft_parser.parse(
                raw, sector_size=self.geometry.bytes_per_sector
            )
            attributes = self.attribute_parser.parse(
                record.fixed_record,
                record.first_attribute_offset,
                record.used_size,
            )
        except Exception as exc:
            return {
                "passed": False,
                "offset": offset,
                "error": f"{type(exc).__name__}: {exc}",
            }

        names = []
        data_attributes = []
        warnings = []

        for attr in attributes:
            if attr.type_id == self.FILE_NAME_ATTRIBUTE and attr.value:
                try:
                    parsed_name = self.filename_parser.parse(attr.value)
                    names.append({
                        "name": parsed_name.name,
                        "parent_record_id": parsed_name.parent_record_id,
                        "parent_sequence_number": parsed_name.parent_sequence_number,
                        "namespace": parsed_name.namespace,
                        "real_size": parsed_name.real_size,
                        "allocated_size": parsed_name.allocated_size,
                        "file_flags": parsed_name.file_flags,
                    })
                except Exception as exc:
                    warnings.append(f"Filename attribute rejected: {exc}")

            elif attr.type_id == self.DATA_ATTRIBUTE:
                if attr.non_resident:
                    try:
                        attr_start = attr.attribute_offset
                        run_offset = attr.runlist_offset
                        if (not isinstance(attr_start, int) or attr_start < 0
                                or not isinstance(run_offset, int) or run_offset < 64):
                            raise ValueError("invalid attribute-relative runlist offset")
                        start = attr_start + run_offset
                        attr_end = attr_start + attr.length
                        if start >= attr_end or attr_end > record.used_size:
                            raise ValueError("runlist exceeds its attribute bounds")
                        run_bytes = record.fixed_record[start:attr_end]
                        runs = self.run_parser.parse(
                            run_bytes, start_vcn=attr.lowest_vcn
                        )
                        data_attributes.append({
                            "resident": False,
                            "real_size": attr.real_size,
                            "lowest_vcn": attr.lowest_vcn,
                            "highest_vcn": attr.highest_vcn,
                            "runs": [
                                {
                                    "vcn": r.vcn,
                                    "lcn": r.lcn,
                                    "clusters": r.clusters,
                                    "sparse": r.sparse,
                                } for r in runs
                            ],
                        })
                    except Exception as exc:
                        warnings.append(f"Data runlist rejected: {exc}")
                else:
                    resident_value = bytes(attr.value or b"")
                    data_attributes.append({
                        "resident": True,
                        "real_size": len(resident_value),
                        "resident_data_available": bool(resident_value),
                        "resident_data_hex": resident_value.hex(),
                        "sha256": hashlib.sha256(resident_value).hexdigest(),
                    })

        in_use = bool(record.flags & 0x0001)
        return {
            "passed": True,
            "offset": offset,
            "sequence_number": record.sequence_number,
            "flags": record.flags,
            "in_use": in_use,
            # A free MFT record alone is not sufficient evidence of a
            # recoverable deleted file; require parsed filename and data metadata.
            "deleted_candidate": (
                not in_use and bool(names) and bool(data_attributes)
            ),
            "filenames": names,
            "data_attributes": data_attributes,
            "warnings": warnings,
            "scope": "MFT metadata parsed; deleted content not yet proven recoverable",
        }

    def discover_and_parse(self, max_records=10000) -> dict[str, Any]:
        """Discover structurally plausible MFT records and parse each one."""
        if isinstance(max_records, bool) or not isinstance(max_records, int) or not 1 <= max_records <= 100000:
            raise ValueError("max_records must be between 1 and 100000")

        from engine.filesystem.mft_discovery_engine import MFTDiscoveryEngine

        status = self.image.inspect()
        if not status.get("ready"):
            return {"passed": False, "error": status.get("error", "Image unavailable")}

        start = (
            self.partition_offset
            + self.geometry.mft_lcn * self.geometry.cluster_size
        )
        end = min(
            status["size"],
            start + max_records * self.geometry.mft_record_size,
        )
        try:
            discovery = MFTDiscoveryEngine(
                self.image,
                sector_size=self.geometry.bytes_per_sector,
                record_size=self.geometry.mft_record_size,
            )
            locations = discovery.discover(
                start=start, end=end, max_records=max_records
            )
        except Exception as exc:
            return {"passed": False, "stage": "discovery",
                    "error": f"{type(exc).__name__}: {exc}"}

        parsed = [self.parse_record_at(item.offset) for item in locations]
        valid = [item for item in parsed if item.get("passed") is True]
        deleted = [item for item in valid if item.get("deleted_candidate") is True]
        return {
            "passed": True,
            "records_discovered": len(locations),
            "records_parsed": len(valid),
            "deleted_metadata_candidates": len(deleted),
            "records": parsed,
            "scope": "candidate metadata only; no claim that file contents are intact",
        }

    def recover_deleted_record(
        self,
        record_offset: int,
        destination,
        expected_sha256: str | None = None,
        filename_index: int = 0,
        data_index: int = 0,
        evidence_ledger=None,
        evidence_case_id: str | None = None,
    ) -> dict[str, Any]:
        """Connect MFT metadata, bounded reconstruction, and optional evidence.

        If an evidence ledger is supplied, a verified evidence record is
        required for the result to be reported as fully passed.

        The caller must provide an image offset discovered or otherwise
        validated for the correct volume. A metadata candidate is not proof
        that deleted content is intact.
        """
        metadata = self.parse_record_at(record_offset)
        if metadata.get("passed") is not True:
            return {
                "passed": False,
                "stage": "mft_record_parse",
                "error": metadata.get("error", "MFT record could not be parsed"),
            }

        if metadata.get("deleted_candidate") is not True:
            return {
                "passed": False,
                "stage": "candidate_validation",
                "error": "Record is not a validated deleted metadata candidate",
            }

        names = metadata.get("filenames", [])
        attrs = metadata.get("data_attributes", [])
        if not isinstance(names, list) or not names:
            return {"passed": False, "stage": "filename_link", "error": "No filename metadata"}
        if not isinstance(attrs, list) or not attrs:
            return {"passed": False, "stage": "data_attribute", "error": "No data attribute"}

        if isinstance(filename_index, bool) or not isinstance(filename_index, int) or not 0 <= filename_index < len(names):
            raise ValueError("filename_index is outside available filename metadata")
        if isinstance(data_index, bool) or not isinstance(data_index, int) or not 0 <= data_index < len(attrs):
            raise ValueError("data_index is outside available data attributes")

        filename = names[filename_index]
        attr = attrs[data_index]
        if attr.get("resident") is True:
            # Resident NTFS data is stored inside the MFT attribute itself.
            # Never guess clusters or fall back to scanning arbitrary sectors.
            import binascii

            resident_hex = attr.get("resident_data_hex")
            real_size = attr.get("real_size")
            if not isinstance(resident_hex, str):
                return {
                    "passed": False, "stage": "resident_data",
                    "error": "Resident data bytes are unavailable",
                    "filename": filename.get("name"),
                }
            try:
                resident_data = binascii.unhexlify(resident_hex)
            except (ValueError, binascii.Error):
                return {
                    "passed": False, "stage": "resident_data",
                    "error": "Resident data encoding is invalid",
                    "filename": filename.get("name"),
                }

            if (isinstance(real_size, bool) or not isinstance(real_size, int) or real_size <= 0
                    or real_size != len(resident_data)
                    or real_size > self.max_output_size):
                return {
                    "passed": False, "stage": "resident_data",
                    "error": "Resident data size is invalid or exceeds the configured limit",
                    "filename": filename.get("name"),
                }

            if expected_sha256 is not None:
                if (not isinstance(expected_sha256, str)
                        or len(expected_sha256) != 64
                        or any(c not in "0123456789abcdefABCDEF"
                               for c in expected_sha256)):
                    raise ValueError(
                        "expected_sha256 must be a 64-character hexadecimal digest"
                    )

            digest = hashlib.sha256(resident_data).hexdigest()
            if expected_sha256 is not None and digest.lower() != expected_sha256.lower():
                return {
                    "passed": False, "stage": "resident_data_hash",
                    "error": "Resident content does not match expected SHA-256",
                    "filename": filename.get("name"),
                    "expected_sha256": expected_sha256,
                    "actual_sha256": digest,
                    "source_modified": False,
                }

            target = Path(destination).resolve()
            if target == self.image_path:
                raise ValueError("destination must not be the source image")
            if target.exists():
                raise FileExistsError(str(target))

            written = write_recovery_output(target, resident_data)
            verification = verify_output(
                written, expected_size=real_size, expected_sha256=digest
            )
            verified = (
                verification.get("passed") is True
                or verification.get("valid") is True
            )
            result = {
                "passed": verified,
                "stage": "resident_data_recovery",
                "filename": filename.get("name"),
                "record_offset": record_offset,
                "deleted_candidate": True,
                "path": str(written),
                "size": len(resident_data),
                "sha256": digest,
                "expected_sha256": expected_sha256,
                "verification": verification,
                "source_modified": False,
                "scope": "Resident MFT data extracted; independent expected-hash match required for content verification",
            }

            if evidence_ledger is not None:
                if not isinstance(evidence_case_id, str) or not evidence_case_id.strip():
                    raise ValueError(
                        "evidence_case_id is required when evidence_ledger is supplied"
                    )
                evidence_record = evidence_ledger.create_record(
                    evidence_case_id,
                    self.image_path,
                    record_offset,
                    {
                        "filename": filename.get("name"),
                        "record_offset": record_offset,
                        "recovered_path": result.get("path"),
                        "recovered_size": result.get("size"),
                        "recovered_sha256": result.get("sha256"),
                        "expected_sha256": expected_sha256,
                        "recovery_passed": result.get("passed") is True,
                        "source_modified": False,
                    },
                )
                evidence_verification = evidence_ledger.verify_record(evidence_record)
                evidence_valid = evidence_verification.get("valid") is True
                result["evidence"] = {
                    "case_id": evidence_case_id,
                    "record": evidence_record,
                    "verification": evidence_verification,
                    "passed": evidence_valid,
                }
                if not evidence_valid:
                    result["passed"] = False
                    result["evidence_error"] = (
                        "Evidence record integrity verification failed"
                    )
            return result

        runs = attr.get("runs")
        real_size = attr.get("real_size")
        if isinstance(real_size, bool) or not isinstance(real_size, int) or real_size <= 0:
            return {
                "passed": False,
                "stage": "data_validation",
                "error": "Invalid or empty non-resident file size",
                "filename": filename.get("name"),
            }
        if not isinstance(runs, list) or not runs:
            return {
                "passed": False,
                "stage": "runlist_validation",
                "error": "No usable data runs",
                "filename": filename.get("name"),
            }

        normalized_runs = []
        expected_vcn = 0
        for run in runs:
            if not isinstance(run, dict):
                raise ValueError("Invalid runlist entry")

            vcn = run.get("vcn")
            clusters = run.get("clusters")
            sparse = run.get("sparse", False)
            lcn = run.get("lcn")

            if isinstance(vcn, bool) or not isinstance(vcn, int) or vcn != expected_vcn:
                raise ValueError(
                    "Incomplete or discontinuous VCN coverage; "
                    "full-file reconstruction requires extents starting at VCN 0"
                )
            if isinstance(clusters, bool) or not isinstance(clusters, int) or clusters <= 0:
                raise ValueError("Invalid run cluster count")
            if not isinstance(sparse, bool):
                raise ValueError("Invalid sparse-run flag")
            if sparse:
                if lcn is not None:
                    raise ValueError("Sparse run must not specify a physical LCN")
            elif isinstance(lcn, bool) or not isinstance(lcn, int) or lcn < 0:
                raise ValueError("Invalid physical cluster location")

            normalized_runs.append({
                "lcn": lcn,
                "clusters": clusters,
                "sparse": sparse,
            })
            expected_vcn += clusters

        result = self.reconstruct_runs(
            normalized_runs, real_size, destination,
            expected_sha256=expected_sha256,
        )
        result["stage"] = "file_reconstruction"
        result["filename"] = filename.get("name")
        result["record_offset"] = record_offset
        result["deleted_candidate"] = True
        result["source_modified"] = False
        result["scope"] = (
            "MFT metadata linked to reconstructed extents; file content "
            "validity depends on independent expected-hash evidence"
        )

        if evidence_ledger is not None:
            if not isinstance(evidence_case_id, str) or not evidence_case_id.strip():
                raise ValueError(
                    "evidence_case_id is required when evidence_ledger is supplied"
                )

            evidence_record = evidence_ledger.create_record(
                evidence_case_id,
                self.image_path,
                record_offset,
                {
                    "filename": filename.get("name"),
                    "record_offset": record_offset,
                    "recovered_path": result.get("path"),
                    "recovered_size": result.get("size"),
                    "recovered_sha256": result.get("sha256"),
                    "expected_sha256": expected_sha256,
                    "recovery_passed": result.get("passed") is True,
                    "source_modified": False,
                },
            )
            evidence_verification = evidence_ledger.verify_record(evidence_record)
            evidence_valid = evidence_verification.get("valid") is True

            result["evidence"] = {
                "case_id": evidence_case_id,
                "record": evidence_record,
                "verification": evidence_verification,
                "passed": evidence_valid,
            }
            if not evidence_valid:
                result["passed"] = False
                result["evidence_error"] = "Evidence record integrity verification failed"

        return result

    def reconstruct_runs(self, runs, real_size: int, destination,
                         expected_sha256: str | None = None) -> dict[str, Any]:
        """Read cluster extents with strict bounds and create-only output."""
        if isinstance(real_size, bool) or not isinstance(real_size, int) or real_size <= 0:
            raise ValueError("real_size must be a positive integer")
        if real_size > self.max_output_size:
            raise ValueError("real_size exceeds max_output_size")

        if expected_sha256 is not None:
            if (not isinstance(expected_sha256, str)
                    or len(expected_sha256) != 64
                    or any(c not in "0123456789abcdefABCDEF" for c in expected_sha256)):
                raise ValueError("expected_sha256 must be a 64-character hexadecimal digest")

        target = Path(destination).resolve()
        if target == self.image_path:
            raise ValueError("destination must not be the source image")
        if target.exists():
            raise FileExistsError(str(target))
        if not isinstance(runs, (list, tuple)) or not runs:
            raise ValueError("non-empty runlist required")

        status = self.image.inspect()
        if not status.get("ready"):
            raise OSError(status.get("error", "Source image unavailable"))
        image_size = status.get("size")
        cluster_size = self.geometry.cluster_size
        output = bytearray()

        physical_ranges = []
        for run in runs:
            if not isinstance(run, dict):
                raise ValueError("invalid runlist entry")

            clusters = run.get("clusters")
            sparse = run.get("sparse", False)
            lcn = run.get("lcn")

            if (not isinstance(clusters, int) or isinstance(clusters, bool)
                    or clusters <= 0):
                raise ValueError("invalid run cluster count")
            if not isinstance(sparse, bool):
                raise ValueError("invalid sparse-run flag")

            if sparse:
                if lcn is not None:
                    raise ValueError("sparse run must not specify a physical LCN")
            else:
                if (not isinstance(lcn, int) or isinstance(lcn, bool)
                        or lcn < 0):
                    raise ValueError("invalid physical cluster location")
                start_cluster = lcn
                end_cluster = lcn + clusters
                if any(start_cluster < old_end and old_start < end_cluster
                       for old_start, old_end in physical_ranges):
                    raise ValueError("overlapping physical cluster extents")
                physical_ranges.append((start_cluster, end_cluster))
            extent_size = clusters * cluster_size
            remaining = real_size - len(output)
            if remaining <= 0:
                break
            take = min(extent_size, remaining)

            if sparse:
                output.extend(b"\x00" * take)
                continue

            if isinstance(lcn, bool) or not isinstance(lcn, int) or lcn < 0:
                raise ValueError("invalid physical cluster location")
            absolute = self.partition_offset + lcn * cluster_size
            if absolute < self.partition_offset or absolute + take > image_size:
                raise ValueError("extent exceeds source image bounds")
            output.extend(self.image.read_at(absolute, take))

        if len(output) != real_size:
            raise ValueError("runlist did not reconstruct the requested file size")

        data = bytes(output)
        digest = hashlib.sha256(data).hexdigest()
        if expected_sha256 is not None and digest.lower() != expected_sha256.lower():
            raise ValueError("Recovered content does not match expected SHA-256")
        written = write_recovery_output(target, data)
        verification = verify_output(
            written, expected_size=real_size, expected_sha256=digest
        )
        verified = (verification.get("passed") is True or verification.get("valid") is True)
        return {
            "passed": verified,
            "path": str(written),
            "size": len(data),
            "sha256": digest,
            "verification": verification,
            "source_modified": False,
            "scope": "extent reconstruction; file format and deleted-file status require independent validation",
        }