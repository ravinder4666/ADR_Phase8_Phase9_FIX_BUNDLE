﻿import unittest
from unittest.mock import patch

from engine.orchestrator import native_deleted_file_recovery as recovery


class DeletedRecordParserTests(unittest.TestCase):
    def test_bad_signature_rejected(self):
        with self.assertRaisesRegex(ValueError, "signature"):
            recovery.parse_deleted_record(b"NOPE" + bytes(1020))

    def test_truncated_record_rejected(self):
        with self.assertRaises(ValueError):
            recovery.parse_deleted_record(b"FILE")

    def test_in_use_record_not_classified_deleted(self):
        record = bytearray(1024)
        record[0:4] = b"FILE"
        record[4:6] = (48).to_bytes(2, "little")
        record[6:8] = (3).to_bytes(2, "little")
        record[16:18] = (1).to_bytes(2, "little")
        record[20:22] = (56).to_bytes(2, "little")
        record[22:24] = (1).to_bytes(2, "little")
        record[24:28] = (56).to_bytes(4, "little")
        record[28:32] = (1024).to_bytes(4, "little")
        record[48:50] = b"\xAA\xBB"
        record[510:512] = b"\xAA\xBB"
        record[1022:1024] = b"\xAA\xBB"
        with patch.object(recovery, "parse_runlist") as parser:
            self.assertIsNone(recovery.parse_deleted_record(bytes(record)))
            parser.assert_not_called()


if __name__ == "__main__":
    unittest.main()
