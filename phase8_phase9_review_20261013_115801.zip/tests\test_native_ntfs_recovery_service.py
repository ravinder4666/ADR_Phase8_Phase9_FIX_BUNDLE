﻿import hashlib
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from engine.orchestrator import native_ntfs_recovery_service as service


class FakePipeline:
    payload = b"NTFS-integration-fixture"

    def __init__(self, *args, **kwargs):
        self.geometry = None

    def inspect_volume(self):
        self.geometry = SimpleNamespace(cluster_size=1)
        return {"passed": True, "cluster_size": 1}

    def extract_verified_bytes(self, runs, real_size, destination):
        if sum(run.clusters for run in runs) < real_size:
            raise ValueError("insufficient extents")
        Path(destination).write_bytes(self.payload[:real_size])
        return {"passed": True}


class NativeNTFSRecoveryServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.image = self.root / "source.img"
        self.output = self.root / "recovered.bin"
        self.payload = FakePipeline.payload
        self.image.write_bytes(self.payload + b"\0" * 64)
        self.runlist = b"\x11\x18\x00"  # parser is mocked in these integration tests
        self.expected = hashlib.sha256(self.payload).hexdigest()

    def tearDown(self):
        self.tmp.cleanup()

    def invoke(self, **overrides):
        args = dict(
            image_path=str(self.image),
            destination=str(self.output),
            raw_runlist=self.runlist,
            real_size=len(self.payload),
            expected_sha256=self.expected,
        )
        args.update(overrides)
        with patch.object(service, "NTFSRecoveryPipeline", FakePipeline), \
             patch.object(service, "parse_runlist", return_value=[
                 {"lcn": 0, "clusters": len(self.payload), "sparse": False}
             ]):
            return service.recover_from_runlist(**args)

    def test_hash_verified_output_published(self):
        source_hash = hashlib.sha256(self.image.read_bytes()).hexdigest()
        result = self.invoke()
        self.assertTrue(result["passed"])
        self.assertEqual(self.output.read_bytes(), self.payload)
        self.assertEqual(hashlib.sha256(self.image.read_bytes()).hexdigest(), source_hash)
        self.assertTrue(result["source_unchanged"])

    def test_wrong_independent_hash_rejected(self):
        with self.assertRaisesRegex(ValueError, "SHA-256"):
            self.invoke(expected_sha256="0" * 64)
        self.assertFalse(self.output.exists())

    def test_existing_destination_not_overwritten(self):
        self.output.write_bytes(b"KEEP")
        with self.assertRaises(FileExistsError):
            self.invoke()
        self.assertEqual(self.output.read_bytes(), b"KEEP")

    def test_sparse_extent_rejected(self):
        with patch.object(service, "parse_runlist", return_value=[
            {"lcn": None, "clusters": 5, "sparse": True}
        ]):
            with self.assertRaisesRegex(ValueError, "Sparse"):
                service._validated_runs(self.runlist)

    def test_invalid_cluster_count_rejected(self):
        with patch.object(service, "parse_runlist", return_value=[
            {"lcn": 0, "clusters": 0, "sparse": False}
        ]):
            with self.assertRaisesRegex(ValueError, "cluster count"):
                service._validated_runs(self.runlist)

    def test_bad_expected_hash_rejected(self):
        with self.assertRaisesRegex(ValueError, "independent SHA-256"):
            self.invoke(expected_sha256="invalid")

    def test_source_destination_collision_rejected(self):
        with self.assertRaisesRegex(ValueError, "source image"):
            self.invoke(destination=str(self.image))

    def test_extent_beyond_image_rejected(self):
        with patch.object(service, "NTFSRecoveryPipeline", FakePipeline), \
             patch.object(service, "parse_runlist", return_value=[
                 {"lcn": 999999, "clusters": 10, "sparse": False}
             ]):
            with self.assertRaisesRegex(ValueError, "boundary"):
                service.recover_from_runlist(
                    str(self.image), str(self.output), self.runlist,
                    real_size=len(self.payload), expected_sha256=self.expected
                )


if __name__ == "__main__":
    unittest.main()

