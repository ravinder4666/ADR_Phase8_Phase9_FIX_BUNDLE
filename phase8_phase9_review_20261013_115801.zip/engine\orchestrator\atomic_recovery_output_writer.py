"""Create-only atomic output writer; refuses to replace existing destinations."""
import os
import tempfile
from pathlib import Path

def write_recovery_output(destination, data: bytes) -> Path:
    target = Path(destination).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise FileExistsError(str(target))
    fd, temp_name = tempfile.mkstemp(prefix=".recovery-", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        # Hard-link creation is atomic and fails if target already exists.
        os.link(temp_name, target)
        return target
    finally:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass