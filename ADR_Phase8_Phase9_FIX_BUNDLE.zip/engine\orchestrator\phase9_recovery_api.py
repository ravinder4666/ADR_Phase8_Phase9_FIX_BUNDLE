"""Explicit, bounded Phase 9 recovery API adapter."""
from __future__ import annotations

import hashlib
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
IMAGE_ROOT = (ROOT / "test_images").resolve()
OUTPUT_ROOT = ROOT / "recovered_files"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def recover_candidate(payload: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(payload, dict):
        raise TypeError("Request must be a JSON object")

    image_name = payload.get("image")
    if not isinstance(image_name, str) or not image_name or Path(image_name).name != image_name:
        raise ValueError("'image' must be a filename inside test_images")

    source = (IMAGE_ROOT / image_name).resolve(strict=True)
    if source.parent != IMAGE_ROOT or not source.is_file():
        raise ValueError("Image must be a regular file directly inside test_images")

    record_offset = payload.get("record_offset")
    if isinstance(record_offset, bool) or not isinstance(record_offset, int) or record_offset < 0:
        raise ValueError("'record_offset' must be a non-negative integer")

    geometry_data = payload.get("geometry")
    if not isinstance(geometry_data, dict):
        raise ValueError("'geometry' must contain validated NTFS geometry")
    required = ("bytes_per_sector", "cluster_size", "mft_record_size", "mft_lcn")
    values = {}
    for key in required:
        value = geometry_data.get(key)
        minimum = 0 if key == "mft_lcn" else 1
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            raise ValueError(f"geometry.{key} is invalid")
        values[key] = value

    partition_offset = payload.get("partition_offset", 0)
    if isinstance(partition_offset, bool) or not isinstance(partition_offset, int) or partition_offset < 0:
        raise ValueError("'partition_offset' must be a non-negative integer")

    destination_name = payload.get("destination")
    if (not isinstance(destination_name, str) or not destination_name
            or Path(destination_name).name != destination_name
            or destination_name in (".", "..")):
        raise ValueError("'destination' must be a plain output filename")

    expected = payload.get("expected_sha256")
    if expected is not None:
        if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", expected):
            raise ValueError("'expected_sha256' must be a 64-character SHA-256 digest")
        expected = expected.lower()

    OUTPUT_ROOT.mkdir(parents=True, exist_ok=True)
    destination = (OUTPUT_ROOT / destination_name).resolve()
    if destination.parent != OUTPUT_ROOT.resolve():
        raise ValueError("Destination must remain inside recovered_files")
    if destination == source or destination.exists():
        raise FileExistsError(str(destination))

    from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration

    geometry = SimpleNamespace(**values)
    source_hash_before = _sha256(source)
    engine = NTFSRecoveryIntegration(
        image_path=source,
        geometry=geometry,
        partition_offset=partition_offset,
    )

    result = engine.recover_deleted_record(
        record_offset=record_offset,
        destination=destination,
        expected_sha256=expected,
    )

    source_hash_after = _sha256(source)
    source_unchanged = source_hash_before == source_hash_after
    output_exists = destination.is_file()
    output_hash = _sha256(destination) if output_exists else None
    output_size = destination.stat().st_size if output_exists else None

    passed = bool(result.get("passed", result.get("valid", False))) if isinstance(result, dict) else bool(result)
    known_hash_match = bool(expected and output_hash == expected and output_exists)
    expected_hash_ok = expected is None or known_hash_match
    return {
        "status": "VERIFIED_OUTPUT" if passed and output_exists and source_unchanged and expected_hash_ok else "NOT_VERIFIED",
        "engine_result": result,
        "source_sha256_before": source_hash_before,
        "source_sha256_after": source_hash_after,
        "source_unchanged": source_unchanged,
        "output_path": str(destination) if output_exists else None,
        "output_size": output_size,
        "output_sha256": output_hash,
        "expected_sha256_supplied": expected is not None,
        "known_original_hash_verified": known_hash_match,
        "limitations": [
            "Only images located directly inside test_images are accepted",
            "Geometry must be supplied from a trusted NTFS inspection",
            "Output SHA-256 alone does not prove the bytes match the original file",
            "A synthetic-image test does not establish real-world recovery capability",
        ],
    }
