﻿from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import hashlib
import struct
import unittest

from engine.orchestrator.ntfs_recovery_integration import NTFSRecoveryIntegration
from engine.orchestrator.recovery_evidence_ledger import RecoveryEvidenceLedger


def make_filename_attribute(filename="fixture.bin", real_size=8):
    name_bytes = filename.encode("utf-16le")
    value = bytearray(66 + len(name_bytes))

    # Parent file reference: record 5, sequence number 1.
    struct.pack_into("<Q", value, 0, (1 << 48) | 5)
    struct.pack_into("<Q", value, 40, real_size)
    struct.pack_into("<Q", value, 48, real_size)
    struct.pack_into("<I", value, 56, 0)
    value[64] = len(filename)
    value[65] = 1
    value[66:] = name_bytes

    length = (24 + len(value) + 7) & ~7
    attr = bytearray(length)
    struct.pack_into("<I", attr, 0, 0x30)
    struct.pack_into("<I", attr, 4, length)
    attr[8] = 0
    struct.pack_into("<H", attr, 14, 1)
    struct.pack_into("<I", attr, 16, len(value))
    struct.pack_into("<H", attr, 20, 24)
    attr[24:24 + len(value)] = value
    return bytes(attr)


def make_data_attribute(real_size=8):
    # Two one-cluster extents: LCN 1, then LCN 3.
    # NTFS runlist uses signed LCN deltas: +1, then +2.
    runlist = b"\x11\x01\x01\x11\x01\x02\x00"
    attr = bytearray(72)
    struct.pack_into("<I", attr, 0, 0x80)
    struct.pack_into("<I", attr, 4, len(attr))
    attr[8] = 1
    struct.pack_into("<H", attr, 14, 2)
    struct.pack_into("<Q", attr, 16, 0)
    struct.pack_into("<Q", attr, 24, 1)
    struct.pack_into("<H", attr, 32, 64)
    struct.pack_into("<Q", attr, 40, 8)
    struct.pack_into("<Q", attr, 48, real_size)
    attr[64:64 + len(runlist)] = runlist
    return bytes(attr)


def make_deleted_mft_record():
    record = bytearray(1024)
    record[:4] = b"FILE"

    # Update Sequence Array for a 1024-byte record with 512-byte sectors.
    usa_offset = 48
    struct.pack_into("<H", record, 4, usa_offset)
    struct.pack_into("<H", record, 6, 3)
    record[usa_offset:usa_offset + 2] = b"\xA5\x5A"
    record[usa_offset + 2:usa_offset + 4] = b"\x00\x00"
    record[usa_offset + 4:usa_offset + 6] = b"\x00\x00"

    struct.pack_into("<H", record, 16, 7)  # Sequence number
    struct.pack_into("<H", record, 20, 56)
    struct.pack_into("<H", record, 22, 0)  # Not in use: deleted candidate

    filename_attr = make_filename_attribute()
    data_attr = make_data_attribute()
    pos = 56
    record[pos:pos + len(filename_attr)] = filename_attr
    pos += len(filename_attr)
    record[pos:pos + len(data_attr)] = data_attr
    pos += len(data_attr)
    struct.pack_into("<I", record, pos, 0xFFFFFFFF)
    used_size = pos + 4

    struct.pack_into("<I", record, 24, used_size)
    struct.pack_into("<I", record, 28, len(record))

    # Protect each sector trailer with the USA sequence value.
    record[510:512] = b"\xA5\x5A"
    record[1022:1024] = b"\xA5\x5A"
    return bytes(record)


class TestRawMFTRecoveryE2E(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        self.image_path = self.folder / "synthetic_ntfs.img"

        image = bytearray(2048)
        image[4:8] = b"ABCD"       # Physical cluster 1
        image[12:16] = b"EFGH"     # Physical cluster 3
        record_offset = 512
        image[record_offset:record_offset + 1024] = make_deleted_mft_record()
        self.image_path.write_bytes(image)

        self.geometry = SimpleNamespace(
            bytes_per_sector=512,
            cluster_size=4,
            mft_record_size=1024,
            mft_lcn=1,
        )
        self.engine = NTFSRecoveryIntegration(self.image_path, self.geometry)

    def test_raw_mft_record_to_recovered_file_and_independent_hash(self):
        output = self.folder / "recovered_fixture.bin"
        before = hashlib.sha256(self.image_path.read_bytes()).hexdigest()
        expected_data = b"ABCDEFGH"
        expected_hash = hashlib.sha256(expected_data).hexdigest()

        metadata = self.engine.parse_record_at(512)
        self.assertTrue(metadata.get("passed"), metadata)
        self.assertTrue(metadata.get("deleted_candidate"), metadata)
        self.assertEqual(metadata["filenames"][0]["name"], "fixture.bin")
        self.assertEqual(metadata["data_attributes"][0]["real_size"], 8)

        result = self.engine.recover_deleted_record(
            512, output, expected_sha256=expected_hash
        )
        self.assertTrue(result.get("passed"), result)
        self.assertEqual(output.read_bytes(), expected_data)
        self.assertEqual(hashlib.sha256(output.read_bytes()).hexdigest(), expected_hash)

        after = hashlib.sha256(self.image_path.read_bytes()).hexdigest()
        self.assertEqual(before, after, "Source image must remain unchanged")

    def test_invalid_usa_fixup_is_rejected_without_output(self):
        damaged = bytearray(self.image_path.read_bytes())
        # Corrupt the first sector trailer of the MFT record.
        damaged[512 + 510] ^= 0xFF
        self.image_path.write_bytes(damaged)

        output = self.folder / "must_not_exist.bin"
        result = self.engine.recover_deleted_record(512, output)

        self.assertFalse(result.get("passed"), result)
        self.assertFalse(output.exists())


    def test_raw_mft_recovery_publishes_verifiable_evidence(self):
        output = self.folder / "evidence_recovered.bin"
        ledger = RecoveryEvidenceLedger(self.folder / "evidence")
        expected_data = b"ABCDEFGH"
        expected_hash = hashlib.sha256(expected_data).hexdigest()
        source_hash_before = hashlib.sha256(self.image_path.read_bytes()).hexdigest()

        result = self.engine.recover_deleted_record(
            512,
            output,
            expected_sha256=expected_hash,
            evidence_ledger=ledger,
            evidence_case_id="raw-mft-e2e",
        )

        self.assertTrue(result.get("passed"), result)
        self.assertEqual(output.read_bytes(), expected_data)
        self.assertEqual(result["sha256"], expected_hash)
        self.assertTrue(result["evidence"]["passed"], result["evidence"])
        self.assertTrue(
            ledger.verify_record(result["evidence"]["record"]).get("valid"),
            result["evidence"],
        )

        saved_record = self.folder / "evidence" / "raw-mft-e2e.evidence.json"
        self.assertTrue(saved_record.is_file(), "Evidence record was not published")
        self.assertTrue(ledger.verify_record(saved_record).get("valid"))

        source_hash_after = hashlib.sha256(self.image_path.read_bytes()).hexdigest()
        self.assertEqual(source_hash_before, source_hash_after)
        self.assertFalse(result["source_modified"])


if __name__ == "__main__":
    unittest.main()
