﻿import json
import hashlib
import http.client
import threading
import unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from urllib.request import urlopen, Request
from urllib.error import HTTPError
from adr_api_server import ADRRequestHandler, ROOT

class TestADRImageInspectionAPI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.folder = ROOT / "test_images"
        cls.folder.mkdir(exist_ok=True)
        cls.sample = cls.folder / "api_inspection_fixture.bin"
        cls.sample.write_bytes(b"ADR-TEST-IMAGE")
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), ADRRequestHandler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = "http://127.0.0.1:" + str(cls.server.server_address[1])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)
        cls.sample.unlink(missing_ok=True)
        try:
            cls.folder.rmdir()
        except OSError:
            pass

    def post(self, image):
        data = json.dumps({"image": image}).encode()
        req = Request(self.base + "/api/image/inspect", data=data,
                      headers={"Content-Type": "application/json"}, method="POST")
        return urlopen(req, timeout=3)

    def test_valid_fixture_metadata(self):
        with self.post(self.sample.name) as response:
            data = json.loads(response.read())
        self.assertTrue(data["ok"])
        self.assertEqual(data["inspection"]["size"], len(b"ADR-TEST-IMAGE"))
        self.assertEqual(data["inspection"]["operation"], "metadata_only_read_only")

    def test_traversal_rejected(self):
        with self.assertRaises(HTTPError) as caught:
            self.post("..\\adr_api_server.py")
        self.assertEqual(caught.exception.code, 400)

    def test_absolute_path_rejected(self):
        with self.assertRaises(HTTPError) as caught:
            self.post(str(ROOT / "adr_api_server.py"))
        self.assertEqual(caught.exception.code, 400)

    def test_missing_file_rejected(self):
        with self.assertRaises(HTTPError) as caught:
            self.post("missing_fixture.bin")
        self.assertEqual(caught.exception.code, 400)

    def test_unknown_post_route_rejected(self):
        req = Request(self.base + "/api/not-enabled", data=b"{}",
                      method="POST")
        with self.assertRaises(HTTPError) as caught:
            urlopen(req, timeout=3)
        self.assertEqual(caught.exception.code, 404)

    def _raw_post(self, headers, body):
        connection = http.client.HTTPConnection(self.base.split("://", 1)[1], timeout=3)
        connection.putrequest("POST", "/api/image/inspect")
        for key, value in headers:
            connection.putheader(key, value)
        connection.endheaders(body)
        response = connection.getresponse()
        status = response.status
        response.read()
        connection.close()
        return status

    def test_malformed_content_length_rejected(self):
        status = self._raw_post([("Content-Length", "abc")], b"{}")
        self.assertEqual(status, 400)

    def test_missing_content_length_rejected(self):
        status = self._raw_post([], b"{}")
        self.assertEqual(status, 400)

    def test_non_object_json_rejected(self):
        req = Request(self.base + "/api/image/inspect", data=b"[]", method="POST")
        with self.assertRaises(HTTPError) as caught:
            urlopen(req, timeout=3)
        self.assertEqual(caught.exception.code, 400)

    def test_malformed_json_rejected(self):
        req = Request(self.base + "/api/image/inspect", data=b"{", method="POST")
        with self.assertRaises(HTTPError) as caught:
            urlopen(req, timeout=3)
        self.assertEqual(caught.exception.code, 400)

    def test_oversized_request_rejected(self):
        body = b"x" * 4097
        status = self._raw_post([("Content-Length", str(len(body)))], body)
        self.assertEqual(status, 413)

    def test_inspection_does_not_modify_source_image(self):
        before = hashlib.sha256(self.sample.read_bytes()).hexdigest()
        with self.post(self.sample.name) as response:
            data = json.loads(response.read())
        self.assertTrue(data["ok"])
        after = hashlib.sha256(self.sample.read_bytes()).hexdigest()
        self.assertEqual(before, after)

if __name__ == "__main__":
    unittest.main()
