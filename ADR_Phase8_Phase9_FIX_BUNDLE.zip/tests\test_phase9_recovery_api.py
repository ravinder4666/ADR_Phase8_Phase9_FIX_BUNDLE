﻿import hashlib
import json
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen

import pytest

from engine.orchestrator import phase9_recovery_api as recovery_api


def payload(**updates):
    value = {
        "image": "fixture.img",
        "record_offset": 512,
        "geometry": {
            "bytes_per_sector": 512,
            "cluster_size": 4096,
            "mft_record_size": 1024,
            "mft_lcn": 1,
        },
        "destination": "restored.bin",
    }
    value.update(updates)
    return value


class FakeEngine:
    output = b"KNOWN-FIXTURE"
    result = {"passed": True}

    def __init__(self, image_path, geometry, partition_offset=0):
        self.image_path = Path(image_path)
        self.geometry = geometry
        self.partition_offset = partition_offset

    def recover_deleted_record(self, record_offset, destination, expected_sha256=None):
        Path(destination).write_bytes(self.output)
        return dict(self.result)


@pytest.fixture
def isolated_adapter(tmp_path, monkeypatch):
    image_root = tmp_path / "test_images"
    image_root.mkdir()
    (image_root / "fixture.img").write_bytes(b"read-only source fixture")
    output_root = tmp_path / "recovered_files"
    monkeypatch.setattr(recovery_api, "IMAGE_ROOT", image_root.resolve())
    monkeypatch.setattr(recovery_api, "OUTPUT_ROOT", output_root)
    from engine.orchestrator import ntfs_recovery_integration
    monkeypatch.setattr(ntfs_recovery_integration, "NTFSRecoveryIntegration", FakeEngine)
    FakeEngine.output = b"KNOWN-FIXTURE"
    FakeEngine.result = {"passed": True}
    return image_root / "fixture.img", output_root


def test_adapter_verifies_source_and_independent_expected_hash(isolated_adapter):
    source, output_root = isolated_adapter
    expected = hashlib.sha256(FakeEngine.output).hexdigest()
    result = recovery_api.recover_candidate(payload(expected_sha256=expected))
    assert result["status"] == "VERIFIED_OUTPUT"
    assert result["source_unchanged"] is True
    assert result["known_original_hash_verified"] is True
    assert Path(result["output_path"]).read_bytes() == FakeEngine.output
    assert result["source_sha256_before"] == result["source_sha256_after"]


def test_adapter_rejects_output_that_disagrees_with_expected_hash(isolated_adapter):
    FakeEngine.output = b"DIFFERENT-BYTES"
    result = recovery_api.recover_candidate(
        payload(expected_sha256=hashlib.sha256(b"KNOWN-ORIGINAL").hexdigest())
    )
    assert result["status"] == "NOT_VERIFIED"
    assert result["known_original_hash_verified"] is False


@pytest.mark.parametrize("changes", [
    {"image": "..\\outside.img"},
    {"destination": "..\\outside.bin"},
    {"record_offset": -1},
    {"geometry": {}},
    {"expected_sha256": "not-a-hash"},
])
def test_adapter_rejects_invalid_request_before_recovery(isolated_adapter, changes):
    with pytest.raises((ValueError, TypeError, FileNotFoundError)):
        recovery_api.recover_candidate(payload(**changes))


def test_api_recovery_route_http_contract(monkeypatch):
    import adr_api_server

    monkeypatch.setattr(
        recovery_api,
        "recover_candidate",
        lambda body: {"status": "NOT_VERIFIED", "source_unchanged": True},
    )
    server = ThreadingHTTPServer(("127.0.0.1", 0), adr_api_server.ADRHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        body = json.dumps(payload()).encode("utf-8")
        request = Request(
            f"http://127.0.0.1:{server.server_port}/api/recoveries",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(request, timeout=5) as response:
            result = json.loads(response.read().decode("utf-8"))
            assert response.status == 200
            assert result["ok"] is True
            assert result["recovery"]["status"] == "NOT_VERIFIED"
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)


def test_real_http_api_recovers_synthetic_raw_mft_fixture(tmp_path, monkeypatch):
    """Exercise HTTP -> adapter -> real MFT parser -> reconstruction without mocks."""
    import hashlib
    import json
    import threading
    from http.server import ThreadingHTTPServer
    from urllib.request import Request, urlopen

    import importlib.util
    fixture_path = Path(__file__).with_name("test_ntfs_raw_mft_e2e.py")
    spec = importlib.util.spec_from_file_location("adr_raw_mft_fixture", fixture_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load raw-MFT fixture helper: {fixture_path}")
    fixture_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fixture_module)
    make_deleted_mft_record = fixture_module.make_deleted_mft_record
    import adr_api_server

    image_root = tmp_path / "test_images"
    image_root.mkdir()
    output_root = tmp_path / "recovered_files"
    monkeypatch.setattr(recovery_api, "IMAGE_ROOT", image_root.resolve())
    monkeypatch.setattr(recovery_api, "OUTPUT_ROOT", output_root)

    image = bytearray(2048)
    image[4:8] = b"ABCD"
    image[12:16] = b"EFGH"
    image[512:1536] = make_deleted_mft_record()
    source = image_root / "fixture.img"
    source.write_bytes(image)

    before = hashlib.sha256(source.read_bytes()).hexdigest()
    expected_data = b"ABCDEFGH"
    expected_hash = hashlib.sha256(expected_data).hexdigest()

    server = ThreadingHTTPServer(("127.0.0.1", 0), adr_api_server.ADRHandler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        body = json.dumps({
            "image": "fixture.img",
            "record_offset": 512,
            "geometry": {
                "bytes_per_sector": 512,
                "cluster_size": 4,
                "mft_record_size": 1024,
                "mft_lcn": 1
            },
            "destination": "api_recovered_fixture.bin",
            "expected_sha256": expected_hash
        }).encode("utf-8")

        request = Request(
            f"http://127.0.0.1:{server.server_port}/api/recoveries",
            data=body,
            headers={"Content-Type": "application/json"},
            method="POST"
        )
        with urlopen(request, timeout=10) as response:
            assert response.status == 200
            envelope = json.loads(response.read().decode("utf-8"))

        recovery = envelope["recovery"]
        output = output_root / "api_recovered_fixture.bin"

        assert envelope["ok"] is True
        assert recovery["status"] == "VERIFIED_OUTPUT", recovery
        assert recovery["source_unchanged"] is True
        assert recovery["known_original_hash_verified"] is True
        assert output.read_bytes() == expected_data
        assert hashlib.sha256(output.read_bytes()).hexdigest() == expected_hash
        assert hashlib.sha256(source.read_bytes()).hexdigest() == before
    finally:
        server.shutdown()
        server.server_close()
        thread.join(timeout=5)
