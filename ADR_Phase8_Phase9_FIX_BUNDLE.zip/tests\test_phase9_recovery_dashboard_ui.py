from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JS = (ROOT / "ui" / "recovery_dashboard.js").read_text(encoding="utf-8-sig")
API = (ROOT / "adr_api_server.py").read_text(encoding="utf-8-sig")
ADAPTER = (ROOT / "engine" / "orchestrator" / "phase9_recovery_api.py").read_text(encoding="utf-8-sig")


def test_recovery_dashboard_posts_supported_form_to_real_api():
    assert 'id="adrRecoverForm"' in JS
    assert 'form.id === "adrRecoverForm"' in JS
    assert 'requestJSON("/api/recoveries"' in JS
    assert 'method: "POST"' in JS
    assert 'body: JSON.stringify(payload)' in JS


def test_recovery_form_collects_required_geometry_and_integrity_inputs():
    for name in (
        "image", "record_offset", "bytes_per_sector", "cluster_size",
        "mft_record_size", "mft_lcn", "destination", "expected_sha256"
    ):
        assert f'name="{name}"' in JS
    assert "partition_offset" in JS
    assert "known_original_hash_verified" in JS
    assert "source_unchanged" in JS
    assert "output_sha256" in JS


def test_dashboard_does_not_claim_real_disk_recovery_or_enable_capabilities():
    assert '"live_recovery": False' in API
    assert '"verified_end_to_end_pipeline": False' in API
    assert '"deleted_file_reconstruction": False' in API
    assert '"hash_verified_recovery": False' in API
    assert "test_images" in ADAPTER
    assert "known_original_hash_verified" in ADAPTER


def test_existing_scan_and_no_overwrite_contracts_remain():
    assert 'id="scanBtn"' in (ROOT / "ui" / "recovery_dashboard.html").read_text(encoding="utf-8-sig")
    assert "async function restoreLatestJob()" in JS
    assert "destination_exists" in (ROOT / "adr_api_server.py").read_text(encoding="utf-8-sig")
