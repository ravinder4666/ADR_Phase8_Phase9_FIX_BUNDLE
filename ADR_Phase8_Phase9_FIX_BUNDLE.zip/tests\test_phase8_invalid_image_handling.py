﻿import hashlib
import tempfile
import unittest
from pathlib import Path

from engine.orchestrator.ntfs_recovery_pipeline import NTFSRecoveryPipeline


class TestPhase8InvalidImageHandling(unittest.TestCase):
    def test_13_byte_fixture_fails_validation_without_uncaught_exception(self):
        with tempfile.TemporaryDirectory() as folder:
            image = Path(folder) / "tiny.img"
            image.write_bytes(b"ADR-TEST-ONLY")
            before = hashlib.sha256(image.read_bytes()).hexdigest()

            result = NTFSRecoveryPipeline(image).inspect_volume()

            after = hashlib.sha256(image.read_bytes()).hexdigest()
            self.assertFalse(result["passed"])
            self.assertEqual(result["stage"], "boot_geometry")
            self.assertTrue(result.get("error"))
            self.assertFalse(result["source_modified"])
            self.assertEqual(before, after)

    def test_truncated_image_does_not_pass_ntfs_inspection(self):
        with tempfile.TemporaryDirectory() as folder:
            image = Path(folder) / "truncated.img"
            image.write_bytes(b"\x00" * 511)

            result = NTFSRecoveryPipeline(image).inspect_volume()

            self.assertFalse(result["passed"])
            self.assertEqual(result["stage"], "boot_geometry")
            self.assertFalse(result["source_modified"])


if __name__ == "__main__":
    unittest.main()
