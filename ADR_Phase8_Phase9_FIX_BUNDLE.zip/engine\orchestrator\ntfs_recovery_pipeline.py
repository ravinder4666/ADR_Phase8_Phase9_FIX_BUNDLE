"""Conservative NTFS image inspection and bounded extraction helpers.

This module does not modify the source image. Candidate discovery is not
proof that deleted content is intact. Use only images you are authorized to examine.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from engine.acquisition.disk_image_workflow_adapter import DiskImageWorkflowAdapter
from engine.filesystem.ntfs_boot_sector_reader import NTFSBootSectorReader
from engine.filesystem.ntfs_mft_parser import NTFSMFTParser
from engine.filesystem.ntfs_attribute_parser import NTFSAttributeParser
from engine.filesystem.ntfs_data_run_parser import NTFSDataRunParser
from engine.filesystem.mft_discovery_engine import MFTDiscoveryEngine
from engine.orchestrator.bounded_fragment_extractor import BoundedFragmentExtractor
from engine.orchestrator.atomic_recovery_output_writer import write_recovery_output
from engine.orchestrator.recovered_output_integrity_verifier import verify_output


class NTFSRecoveryPipeline:
    """Read-only image inspection with explicit, bounded recovery operations."""

    def __init__(self, image_path: str | Path, partition_offset: int = 0,
                 max_output_size: int = 64 * 1024 * 1024):
        if not isinstance(partition_offset, int) or partition_offset < 0:
            raise ValueError("partition_offset must be a non-negative integer")
        if not isinstance(max_output_size, int) or max_output_size <= 0:
            raise ValueError("max_output_size must be a positive integer")

        self.image_path = Path(image_path).resolve()
        self.partition_offset = partition_offset
        self.max_output_size = max_output_size
        self.image = DiskImageWorkflowAdapter(self.image_path)
        self.boot_reader = NTFSBootSectorReader()
        self.mft_parser = NTFSMFTParser()
        self.attribute_parser = NTFSAttributeParser()
        self.run_parser = NTFSDataRunParser()
        self.geometry = None

    def inspect_volume(self) -> dict[str, Any]:
        """Parse boot geometry; does not scan or alter the image."""
        status = self.image.inspect()
        if not status.get("ready"):
            return {"passed": False, "stage": "image_inspection",
                    "error": status.get("error", "Image is not ready")}

        image_size = status.get("size")
        if not isinstance(image_size, int) or image_size <= 0:
            return {"passed": False, "stage": "image_inspection",
                    "error": "Image size is invalid"}

        # Treat short/truncated images as validation failures, not uncaught
        # read-range exceptions. The source image is opened read-only.
        try:
            boot = self.image.read_at(self.partition_offset, 512)
            geometry = self.boot_reader.parse(
                boot, image_size=image_size,
                partition_offset=self.partition_offset
            )
        except (ValueError, TypeError, OSError) as exc:
            return {
                "passed": False,
                "stage": "boot_geometry",
                "error": f"{type(exc).__name__}: {exc}",
                "image_size": image_size,
                "source_modified": False,
            }

        self.geometry = geometry
        return {
            "passed": True,
            "stage": "boot_geometry",
            "image_size": image_size,
            "partition_offset": self.partition_offset,
            "bytes_per_sector": geometry.bytes_per_sector,
            "sectors_per_cluster": geometry.sectors_per_cluster,
            "cluster_size": geometry.cluster_size,
            "volume_size": geometry.volume_size,
            "mft_lcn": geometry.mft_lcn,
            "mft_record_size": geometry.mft_record_size,
            "source_modified": False,
        }

    def discover_mft_records(self, max_records: int = 100_000) -> dict[str, Any]:
        """Find structurally plausible MFT record locations in the image."""
        if self.geometry is None:
            result = self.inspect_volume()
            if not result["passed"]:
                return result

        if not isinstance(max_records, int) or not 1 <= max_records <= 1_000_000:
            raise ValueError("max_records must be between 1 and 1,000,000")

        try:
            discovery = MFTDiscoveryEngine(
                self.image,
                sector_size=self.geometry.bytes_per_sector,
                record_size=self.geometry.mft_record_size,
            )
            mft_start = (
                self.partition_offset
                + self.geometry.mft_lcn * self.geometry.cluster_size
            )
            scan_end = min(
                self.image.inspect()["size"],
                mft_start + max_records * self.geometry.mft_record_size
            )
            candidates = discovery.discover(
                start=mft_start, end=scan_end, max_records=max_records
            )
            return {
                "passed": True,
                "stage": "mft_discovery",
                "candidate_count": len(candidates),
                "candidates": [
                    {
                        "offset": c.offset,
                        "record_size": c.record_size,
                        "sequence_number": c.sequence_number,
                        "flags": c.flags,
                    }
                    for c in candidates
                ],
                "scope": "structural MFT candidates; not confirmed deleted-file recovery",
            }
        except Exception as exc:
            return {"passed": False, "stage": "mft_discovery",
                    "error": f"{type(exc).__name__}: {exc}"}

    def extract_verified_bytes(self, runs, real_size: int,
                               destination: str | Path) -> dict[str, Any]:
        """Extract only caller-supplied, already-validated extents.

        The destination must not exist. This method does not discover extents
        itself and must not be interpreted as proof of deleted-file recovery.
        """
        if not isinstance(real_size, int) or real_size <= 0:
            raise ValueError("real_size must be a positive integer")
        if real_size > self.max_output_size:
            raise ValueError("requested output exceeds configured size limit")

        target = Path(destination).resolve()
        if target == self.image_path:
            raise ValueError("destination cannot be the source image")
        if target.exists():
            raise FileExistsError(str(target))

        if self.geometry is None:
            inspection = self.inspect_volume()
            if not inspection.get("passed"):
                raise ValueError(
                    "Volume geometry must be validated before extraction: "
                    + str(inspection.get("error", "inspection failed"))
                )
        adapter = BoundedFragmentExtractor(
            self.image,
            bytes_per_cluster=self.geometry.cluster_size,
            max_output_size=self.max_output_size,
            partition_offset=self.partition_offset,
        )
        data = adapter.extract(runs, real_size)
        if not isinstance(data, bytes) or len(data) != real_size:
            raise ValueError("extractor returned an unexpected byte count")

        digest = hashlib.sha256(data).hexdigest()
        output = write_recovery_output(target, data)
        verification = verify_output(
            output, expected_size=len(data), expected_sha256=digest
        )
        return {
            "passed": bool(verification.get("passed", False) or verification.get("valid", False)),
            "path": str(output),
            "size": len(data),
            "sha256": digest,
            "verification": verification,
            "source_modified": False,
            "scope": "extent extraction and output integrity only; content recoverability is not guaranteed",
        }