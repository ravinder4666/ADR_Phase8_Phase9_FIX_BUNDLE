from __future__ import annotations

import hashlib
import json
import mimetypes
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit

from engine.orchestrator.phase7_unified_job_service import SERVICE

ROOT = Path(__file__).resolve().parent
UI_ROOT = (ROOT / "ui").resolve()
IMAGE_ROOT = (ROOT / "test_images").resolve()
REPORT_ROOT = (ROOT / "reports" / "phase7").resolve()

# Compatibility alias for existing integrations.
PHASE7_JOBS = SERVICE

CAPABILITIES = {
    "api": True,
    "dashboard_serving": True,
    "read_only_image_acquisition": True,
    "live_scan": True,
    "async_jobs": True,
    "native_structural_validation": True,
    "live_recovery": False,
    "verified_end_to_end_pipeline": False,
    "deleted_file_reconstruction": False,
    "hash_verified_recovery": False,
}

STATIC_FILES = {
    "/": "recovery_dashboard.html",
    "/recovery_dashboard.html": "recovery_dashboard.html",
    "/recovery_dashboard.css": "recovery_dashboard.css",
    "/recovery_dashboard.js": "recovery_dashboard.js",
}
MAX_REQUEST_BYTES = 4096


class ADRHandler(BaseHTTPRequestHandler):
    server_version = "ADRLocalAPI/1.0"

    def log_message(self, fmt, *args):
        print("[ADR API] " + (fmt % args))

    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        if isinstance(payload, (dict, list)):
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        elif isinstance(payload, str):
            body = payload.encode("utf-8")
        else:
            body = payload
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _error(self, status, message, code=None):
        data = {"ok": False, "error": message}
        if code:
            data["code"] = code
        self._send(status, data)

    def _read_json(self):
        raw_length = self.headers.get("Content-Length", "")
        try:
            length = int(raw_length)
        except (TypeError, ValueError):
            raise ValueError("Valid Content-Length is required")
        if length < 0 or length > MAX_REQUEST_BYTES:
            raise OverflowError("Request body exceeds 4096 bytes")
        raw = self.rfile.read(length)
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise ValueError("Request body must be valid JSON")
        if not isinstance(value, dict):
            raise ValueError("JSON object required")
        return value

    def _job_id(self, path, suffix=""):
        pattern = r"^/api/jobs/([a-fA-F0-9]{32})" + re.escape(suffix) + r"$"
        match = re.fullmatch(pattern, path)
        return match.group(1) if match else None

    def _serve_static(self, path):
        name = STATIC_FILES.get(path)
        if not name:
            return False
        target = (UI_ROOT / name).resolve()
        try:
            target.relative_to(UI_ROOT)
        except ValueError:
            self._error(403, "Invalid static resource path")
            return True
        if not target.is_file():
            self._error(404, "Dashboard asset not found: " + name)
            return True
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/javascript",):
            content_type += "; charset=utf-8"
        self._send(200, target.read_bytes(), content_type)
        return True

    def do_GET(self):
        path = unquote(urlsplit(self.path).path)

        if path == "/api/health":
            self._send(200, {
                "ok": True, "mode": "local_api_foundation",
                "service": "AdvancedDataRecovery",
                "status": "healthy",
            })
            return

        if path == "/api/capabilities":
            self._send(200, {"ok": True, "capabilities": CAPABILITIES})
            return

        if path == "/api/images":
            images = []
            IMAGE_ROOT.mkdir(parents=True, exist_ok=True)
            for item in sorted(IMAGE_ROOT.iterdir(), key=lambda p: p.name.lower()):
                try:
                    if item.is_symlink() or not item.is_file():
                        continue
                    size = item.stat().st_size
                    if size <= 0:
                        continue
                    images.append({
                        "name": item.name,
                        "size_bytes": size,
                        "size": size,
                    })
                except OSError:
                    continue
            self._send(200, {"ok": True, "images": images, "count": len(images)})
            return

        job_id = self._job_id(path)
        if job_id:
            try:
                self._send(200, {"ok": True, "job": PHASE7_JOBS.get(job_id)})
            except KeyError:
                self._error(404, "Job not found", "job_not_found")
            return

        report_job_id = self._job_id(path, "/report")
        if report_job_id:
            try:
                job = PHASE7_JOBS.get(report_job_id)
            except KeyError:
                self._error(404, "Job not found", "job_not_found")
                return
            if job.get("status") != "COMPLETED":
                self._error(409, "Report is available only after a completed scan",
                            "report_not_ready")
                return
            report_path = (REPORT_ROOT / (report_job_id + ".json")).resolve()
            try:
                report_path.relative_to(REPORT_ROOT)
            except ValueError:
                self._error(403, "Invalid report path")
                return
            if not report_path.is_file():
                self._error(404, "Completed job report not found", "report_not_found")
                return
            try:
                report = json.loads(report_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                self._error(500, "Report could not be read", "report_read_error")
                return
            self._send(200, {"ok": True, "report": report})
            return

        if path == "/api/jobs":
            self._send(200, {"ok": True, "jobs": PHASE7_JOBS.list_jobs()})
            return

        if self._serve_static(path):
            return
        self._error(404, "Endpoint not found", "not_found")

    def do_POST(self):
        path = unquote(urlsplit(self.path).path)
        try:
            payload = self._read_json()
        except OverflowError as exc:
            self._error(413, str(exc), "request_too_large")
            return
        except ValueError as exc:
            self._error(400, str(exc), "invalid_request")
            return

        if path == "/api/recoveries":
            try:
                from engine.orchestrator.phase9_recovery_api import recover_candidate
                result = recover_candidate(payload)
                self._send(200, {"ok": True, "recovery": result})
            except FileNotFoundError:
                self._error(404, "Source image not found", "image_not_found")
            except FileExistsError:
                self._error(409, "Destination already exists; overwrite refused", "destination_exists")
            except (ValueError, TypeError, KeyError) as exc:
                self._error(400, str(exc), "invalid_recovery_request")
            except Exception:
                self._error(500, "Recovery failed; inspect server logs", "recovery_failed")
            return

        if path == "/api/scans":
            try:
                job = PHASE7_JOBS.create(payload)
                self._send(202, {"ok": True, "job": job})
            except ValueError as exc:
                self._error(400, str(exc), "invalid_scan_request")
            except FileNotFoundError:
                self._error(400, "Image is unavailable", "image_unavailable")
            except Exception as exc:
                self._error(500, "Unable to create scan job: " + type(exc).__name__,
                            "job_creation_failed")
            return

        cancel_job_id = self._job_id(path, "/cancel")
        if cancel_job_id:
            try:
                self._send(200, {
                    "ok": True,
                    "job": PHASE7_JOBS.cancel(cancel_job_id),
                })
            except KeyError:
                self._error(404, "Job not found", "job_not_found")
            return

        if path == "/api/image/inspect":
            name = payload.get("image")
            if not isinstance(name, str) or not name.strip() or name in {".", ".."} \
                    or "/" in name or "\\" in name or "\x00" in name:
                self._error(400, "image must be a filename inside test_images",
                            "invalid_image")
                return
            candidate = (IMAGE_ROOT / name).resolve()
            try:
                candidate.relative_to(IMAGE_ROOT)
            except ValueError:
                self._error(400, "Image path is outside test_images", "invalid_image")
                return
            if candidate.is_symlink() or not candidate.is_file():
                self._error(400, "Image not found", "image_unavailable")
                return
            try:
                digest = hashlib.sha256()
                with candidate.open("rb") as stream:
                    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(chunk)
                size_bytes = candidate.stat().st_size
                sha256 = digest.hexdigest()
                self._send(200, {
                    "ok": True,
                    "inspection": {
                        "name": candidate.name,
                        "size": size_bytes,
                        "operation": "metadata_only_read_only",
                        "sha256": sha256,
                        "source_modified": False,
                        "inspection_only": True,
                        "recoverability_proven": False,
                    },
                    "image": {
                        "name": candidate.name,
                        "size_bytes": size_bytes,
                        "sha256": sha256,
                        "source_modified": False,
                        "inspection_only": True,
                        "recoverability_proven": False,
                    },
                })
            except OSError:
                self._error(500, "Image inspection failed", "inspection_failed")
            return

        self._error(404, "Endpoint not found", "not_found")


def main():
    IMAGE_ROOT.mkdir(parents=True, exist_ok=True)
    REPORT_ROOT.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer(("127.0.0.1", 8765), ADRHandler)
    print("Advanced Data Recovery API: http://127.0.0.1:8765")
    print("Dashboard: http://127.0.0.1:8765/")
    print("Read-only scan enabled; verified file recovery remains disabled.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()

# Backward compatibility for existing API tests
ADRRequestHandler = ADRHandler

